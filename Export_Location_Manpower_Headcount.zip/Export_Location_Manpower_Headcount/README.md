# Location Manpower & Buffer Headcount Master — Complete Module Export

This export package consolidates **all database, backend, and frontend files** required for the **Location Manpower & Buffer Headcount Master** page (`/dash/recruitment/recruitmentdashboard/location-manpower-headcount`).

---

## 📁 Directory Structure

```
Export_Location_Manpower_Headcount/
│
├── README.md                                          <-- This deployment guide
│
├── Database/                                          <-- All SQL migrations and Stored Procedures
│   ├── 01_ALTER_Location_Mst_Add_Manpower_Buffer.sql   <-- Schema alteration for Location_Mst
│   ├── 02_SP_Location_Update_Manpower_Buffer.sql       <-- Stored Procedure to update buffer & capacity
│   ├── 03_UPDATE_Location_Mst_Initial_Buffer_Data.sql  <-- Initial seed/data calculation script
│   └── 09_USP_REC_GetLocationManpowerList.sql          <-- Company-scoped location manpower roster SP
│
├── Backend/                                           <-- WebAPI Controller & DTOs
│   └── AtsJobRequisitionController.cs                 <-- Controller containing manpower endpoints
│
└── Frontend/                                          <-- Angular Standalone Component, Service & Routes
    ├── location-manpower-headcount/
    │   ├── location-manpower-headcount.component.ts   <-- TypeScript logic & reactive computations
    │   ├── location-manpower-headcount.component.html <-- UI template (Bento cards, table, dedicated form)
    │   └── location-manpower-headcount.component.scss <-- Component-scoped styles (ATS Suite theme)
    ├── services/
    │   └── ats.service.ts                             <-- AtsService with manpower API client methods
    └── routes/
        └── recruitment.routes.ts                      <-- Routing configuration for the page
```

---

## 1. 🗄️ Database Changes (`Database/`)

### 1.1 Schema Alteration: `Location_Mst`
**File**: `Database/01_ALTER_Location_Mst_Add_Manpower_Buffer.sql`
- Adds the following columns to `dbo.Location_Mst`:
  - `BaseDemand INT NULL DEFAULT 0`: Base required manpower for the location.
  - `BufferPercent DECIMAL(5,2) NULL DEFAULT 10.00`: Buffer percentage (e.g. 5%, 10%, 15%, 20%).
  - `BufferHeads INT NULL DEFAULT 0`: Computed buffer headcount (`CEILING(BaseDemand * BufferPercent / 100)`).
  - `TargetCapacity INT NULL DEFAULT 0`: Total sanctioned headcount capacity (`BaseDemand + BufferHeads`).

### 1.2 Stored Procedure: `dbo.Location_Update_Manpower_Buffer`
**File**: `Database/02_SP_Location_Update_Manpower_Buffer.sql`
- **Parameters**: `@pk_locid VARCHAR(50)`, `@BaseDemand INT`, `@BufferPercent DECIMAL(5,2)`, `@ModifiedBy VARCHAR(50)`.
- Updates `BaseDemand` and `BufferPercent`.
- Automatically computes:
  $$\text{BufferHeads} = \left\lceil \frac{\text{BaseDemand} \times \text{BufferPercent}}{100} \right\rceil$$
  $$\text{TargetCapacity} = \text{BaseDemand} + \text{BufferHeads}$$
- Returns updated metrics with status and message.

### 1.3 Initial Data Seeding
**File**: `Database/03_UPDATE_Location_Mst_Initial_Buffer_Data.sql`
- Seeds realistic initial buffer parameters across all locations where not already set.

### 1.4 Company-Scoped Query Stored Procedure: `dbo.usp_REC_GetLocationManpowerList`
**File**: `Database/09_USP_REC_GetLocationManpowerList.sql`
- **Parameters**: `@CompanyId NVARCHAR(50) = NULL` (Multi-tenant scoped).
- Queries `Location_Mst` joining `SAL_Employee_Mst` to return:
  - Location identity: `pk_locid`, `locname`, `locationCode`, `state`, `zone`.
  - Metrics: `BaseDemand`, `BufferPercent`, `BufferHeads`, `TargetCapacity`.
  - Actual Headcount: `ActiveEmployeeCount` (live active staff deployed at that hub).
  - `UtilizationPercent`: $\frac{\text{ActiveEmployeeCount}}{\text{TargetCapacity}} \times 100\%$.

---

## 2. ⚙️ Backend WebAPI (`Backend/`)

**File**: `Backend/AtsJobRequisitionController.cs`

### 2.1 API Endpoints
1. **Update Location Buffer**:
   - **Method**: `POST`
   - **Route**: `api/v1/AtsJobRequisition/UpdateLocationManpowerBuffer`
   - **Body**: `LocationBufferUpdateDto`
     ```json
     {
       "locationId": "LOC-12",
       "baseDemand": 150,
       "bufferPercent": 10.0,
       "modifiedBy": "Admin"
     }
     ```
   - **Action**: Calls `dbo.Location_Update_Manpower_Buffer`.

2. **Get Location Manpower List**:
   - **Method**: `GET`
   - **Route**: `api/v1/AtsJobRequisition/GetLocationManpowerList?companyId={companyId}`
   - **Action**: Calls `dbo.usp_REC_GetLocationManpowerList` with dynamic company scoping.

### 2.2 DTO Model
```csharp
public class LocationBufferUpdateDto
{
    public string LocationId { get; set; } = "";
    public int BaseDemand { get; set; }
    public decimal BufferPercent { get; set; }
    public string? ModifiedBy { get; set; }
}
```

---

## 3. 🎨 Frontend Angular (`Frontend/`)

### 3.1 Component
- **Path**: `Frontend/location-manpower-headcount/`
- **Selector**: `<app-location-manpower-headcount>`
- **Standalone**: `true`
- **Features**:
  - **Bento KPI Metric Summary Cards**: Total Locations, Total Base Sanctioned, Total Buffer Heads, Total Target Capacity.
  - **Master Requisition Roster Table**: Searchable, paginated list of all operational hubs with visual capacity badges.
  - **Quick Buffer Presets**: Clickable pills (`0%`, `5%`, `8%`, `10%`, `12%`, `15%`, `20%`).
  - **Dedicated Form View**: Add new location capacity or Edit existing location capacity with real-time reactive buffer computations.
  - **Design System**: Fully adheres to ATS Suite theme (`Work Sans`, `#f6f8fa` canvas, `#0051d5` corporate action buttons, strictly component-scoped SCSS).

### 3.2 Service Methods (`Frontend/services/ats.service.ts`)
```typescript
updateLocationManpowerBuffer(dto: { locationId: string; baseDemand: number; bufferPercent: number; modifiedBy?: string }): Observable<any>
getLocationManpowerList(companyId?: string): Observable<any>
```

### 3.3 Routing (`Frontend/routes/recruitment.routes.ts`)
```typescript
{
  path: 'location-manpower-headcount',
  loadComponent: () => import('./location-manpower-headcount/location-manpower-headcount.component')
    .then((m) => m.LocationManpowerHeadcountComponent),
}
```

---

## 4. 🚀 Quick Deployment / Re-application Steps

1. **Database**:
   Run the scripts in `Database/` against `HRBook_22` (or your target catalog) in sequence:
   ```bash
   sqlcmd -S localhost -d HRBook_22 -U sa -P 123456 -i Database\01_ALTER_Location_Mst_Add_Manpower_Buffer.sql
   sqlcmd -S localhost -d HRBook_22 -U sa -P 123456 -i Database\02_SP_Location_Update_Manpower_Buffer.sql
   sqlcmd -S localhost -d HRBook_22 -U sa -P 123456 -i Database\03_UPDATE_Location_Mst_Initial_Buffer_Data.sql
   sqlcmd -S localhost -d HRBook_22 -U sa -P 123456 -i Database\09_USP_REC_GetLocationManpowerList.sql
   ```
2. **Backend**:
   Verify endpoints in `AtsJobRequisitionController.cs` and ensure the project builds:
   ```bash
   dotnet build WebAPI/HRMSWebAPI.csproj
   ```
3. **Frontend**:
   Verify route and component files in `Frontend/src/app/pages/all-dashboard/recruitment/location-manpower-headcount/`:
   ```bash
   ng build
   ```
