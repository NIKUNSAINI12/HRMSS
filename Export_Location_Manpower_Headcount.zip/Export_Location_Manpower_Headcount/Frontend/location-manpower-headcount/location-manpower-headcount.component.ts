import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AtsService } from '../../../../shared/services/ats.service';
import { LocationMasterService } from '../../user/services/location-master.service';

export interface LocationMasterRecord {
  locationId: string;
  locationName: string;
  locationCode: string;
  state: string;
  zone: string;

  // Headcount & Buffer Master Metrics
  baseRequired: number;
  bufferPercentage: number;
  bufferHeadcount: number;
  totalTargetCapacity: number;

  lastUpdatedDate: string;
  lastUpdatedBy: string;
  remarks?: string;
}

@Component({
  selector: 'app-location-manpower-headcount',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './location-manpower-headcount.component.html',
  styleUrls: ['./location-manpower-headcount.component.scss']
})
export class LocationManpowerHeadcountComponent implements OnInit {
  protected readonly Math = Math;
  private toastr = inject(ToastrService);
  private atsService = inject(AtsService);
  private locationMasterService = inject(LocationMasterService);

  // View Navigation State ('list' for main table, 'edit' or 'add' for dedicated page)
  currentView: 'list' | 'edit' | 'add' = 'list';

  // Buffer Preset Choices (matching ATS theme)
  presetOptions: number[] = [0, 5, 8, 10, 12, 15, 20];

  // Master Available Hub Directory (Dynamically loaded from company-specific Location_Mst)
  availableHubMasterList: any[] = [];

  // Search & Filter State
  searchQuery: string = '';

  // Pagination
  currentPage: number = 1;
  pageSize: number = 10;
  totalPages: number = 1;

  // Master Records List
  allMasterRecords: LocationMasterRecord[] = [];
  filteredMasterRecords: LocationMasterRecord[] = [];

  // Summary Metrics
  totalRecordsCount: number = 0;
  totalBaseSanctioned: number = 0;
  totalBufferHeadcount: number = 0;
  totalTargetCapacity: number = 0;

  // Form Fields for Dedicated Add / Edit Page
  editingLocationId: string | null = null;
  formLocationId: string = '';
  formLocationName: string = '';
  formLocationCode: string = '';
  formState: string = '';

  formBaseRequired: number = 100;
  formBufferPercentage: number = 10;
  formRemarks: string = '';

  // Real-Time Computed Getters for Dedicated Form Page
  get formComputedBufferHeadcount(): number {
    return Math.ceil(Number(this.formBaseRequired || 0) * (Number(this.formBufferPercentage || 0) / 100));
  }

  get formComputedTargetCapacity(): number {
    return Number(this.formBaseRequired || 0) + this.formComputedBufferHeadcount;
  }

  // Get list of hubs available for new registration
  get unassignedHubs(): any[] {
    return this.availableHubMasterList.filter(h => !this.allMasterRecords.some(r => r.locationId === h.id));
  }

  ngOnInit(): void {
    this.loadCompanyLocationsData();
  }

  // ── 1. LOAD COMPANY-SPECIFIC MASTER LOCATIONS FROM BACKEND ─────────────────────────
  loadCompanyLocationsData(): void {
    const companyId = sessionStorage.getItem('companyId') || localStorage.getItem('fk_companyId') || localStorage.getItem('companyId') || sessionStorage.getItem('fk_companyId') || '';
    const userId = sessionStorage.getItem('userId') || localStorage.getItem('userId') || localStorage.getItem('fk_UserID') || 'GU-1';

    this.atsService.getRequisitionMasterData(userId, '', companyId).subscribe({
      next: (res) => {
        if (res && res.locations && res.locations.length > 0) {
          this.availableHubMasterList = res.locations.map((loc: any) => ({
            id: loc.id?.toString() || loc.code,
            name: loc.name || loc.locname,
            code: loc.code || loc.locationCode || 'HUB',
            zone: loc.zone || 'General Zone',
            state: loc.state || 'Operational Hub'
          }));

          this.allMasterRecords = res.locations.map((loc: any) => {
            const base = loc.baseDemand != null ? Number(loc.baseDemand) : 0;
            const buffer = loc.bufferPercent != null ? Number(loc.bufferPercent) : 0;
            const bufferCount = loc.bufferHeads != null ? Number(loc.bufferHeads) : Math.ceil(base * (buffer / 100));
            const target = loc.targetCapacity != null ? Number(loc.targetCapacity) : (base + bufferCount);

            return {
              locationId: loc.id?.toString() || loc.code,
              locationName: loc.name || loc.locname,
              locationCode: loc.code || loc.locationCode || 'HUB',
              state: loc.state || 'Operational Hub',
              zone: loc.zone || 'General Zone',
              baseRequired: base,
              bufferPercentage: buffer,
              bufferHeadcount: bufferCount,
              totalTargetCapacity: target,
              lastUpdatedDate: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
              lastUpdatedBy: this.currentLoggedInUserName,
              remarks: loc.currentOccupied ? `${loc.currentOccupied} Active Employees` : 'Master Hub'
            };
          });

          this.recalculateSummary();
        } else {
          this.recalculateSummary();
        }
      },
      error: () => {
        this.recalculateSummary();
      }
    });
  }



  // ── 2. RECALCULATE SUMMARY ────────────────────────────────────────────────
  recalculateSummary(): void {
    this.totalRecordsCount = this.allMasterRecords.length;
    this.totalBaseSanctioned = this.allMasterRecords.reduce((sum, r) => sum + r.baseRequired, 0);
    this.totalBufferHeadcount = this.allMasterRecords.reduce((sum, r) => sum + r.bufferHeadcount, 0);
    this.totalTargetCapacity = this.allMasterRecords.reduce((sum, r) => sum + r.totalTargetCapacity, 0);

    this.applyFilters();
  }

  // ── 3. FILTERING & PAGINATION ─────────────────────────────────────────────
  applyFilters(): void {
    let list = [...this.allMasterRecords];

    if (this.searchQuery.trim()) {
      const q = this.searchQuery.toLowerCase();
      list = list.filter(l =>
        l.locationName.toLowerCase().includes(q) ||
        l.locationCode.toLowerCase().includes(q) ||
        l.state.toLowerCase().includes(q) ||
        l.locationId.toLowerCase().includes(q)
      );
    }

    this.filteredMasterRecords = list;
    this.totalPages = Math.ceil(this.filteredMasterRecords.length / this.pageSize) || 1;
    this.currentPage = 1;
  }

  get paginatedList(): LocationMasterRecord[] {
    const start = (this.currentPage - 1) * this.pageSize;
    return this.filteredMasterRecords.slice(start, start + this.pageSize);
  }

  goToPage(p: number): void {
    if (p >= 1 && p <= this.totalPages) {
      this.currentPage = p;
    }
  }

  // ── 4. DEDICATED PAGE NAVIGATION (ADD / EDIT) ───────────────────────────
  openAddPage(): void {
    this.currentView = 'add';
    this.editingLocationId = null;

    // Pick first available hub or default
    const available = this.unassignedHubs[0] || this.availableHubMasterList[0];
    this.onSelectHub(available.id);

    this.formBaseRequired = 100;
    this.formBufferPercentage = 10;
    this.formRemarks = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  openEditPage(record: LocationMasterRecord): void {
    this.currentView = 'edit';
    this.editingLocationId = record.locationId;

    // Lock location identity (Cannot be altered in edit page)
    this.formLocationId = record.locationId;
    this.formLocationName = record.locationName;
    this.formLocationCode = record.locationCode;
    this.formState = record.state;

    // Load editable metrics
    this.formBaseRequired = record.baseRequired;
    this.formBufferPercentage = record.bufferPercentage;
    this.formRemarks = record.remarks || '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  backToList(): void {
    this.currentView = 'list';
    this.editingLocationId = null;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  onSelectHub(hubId: string): void {
    const found = this.availableHubMasterList.find(h => h.id === hubId);
    if (found) {
      this.formLocationId = found.id;
      this.formLocationName = found.name;
      this.formLocationCode = found.code;
      this.formState = found.state;
    }
  }

  selectBufferPreset(pct: number): void {
    this.formBufferPercentage = pct;
  }

  get currentLoggedInUserName(): string {
    return sessionStorage.getItem('username') ||
      localStorage.getItem('username') ||
      sessionStorage.getItem('name') ||
      localStorage.getItem('name') ||
      localStorage.getItem('fk_UserID') ||
      'Admin';
  }

  saveMasterRecord(): void {
    if (!this.formLocationName || this.formBaseRequired < 1) {
      this.toastr.warning('Please select a valid location and enter a base headcount requirement.', 'Validation');
      return;
    }

    const bufferCount = this.formComputedBufferHeadcount;
    const target = this.formComputedTargetCapacity;
    const dateStr = new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
    const user = this.currentLoggedInUserName;
    const targetLocId = this.currentView === 'edit' && this.editingLocationId ? this.editingLocationId : this.formLocationId;

    const payload = {
      locationId: targetLocId,
      baseDemand: Number(this.formBaseRequired),
      bufferPercent: Number(this.formBufferPercentage),
      modifiedBy: user
    };

    // Invoke API to persist to Location_Mst via Location_Update_Manpower_Buffer SP
    this.atsService.updateLocationManpowerBuffer(payload).subscribe({
      next: (res) => {
        if (res && res.success) {
          const idx = this.allMasterRecords.findIndex(r => r.locationId === targetLocId);
          if (idx !== -1) {
            this.allMasterRecords[idx] = {
              ...this.allMasterRecords[idx],
              baseRequired: Number(this.formBaseRequired),
              bufferPercentage: Number(this.formBufferPercentage),
              bufferHeadcount: bufferCount,
              totalTargetCapacity: target,
              lastUpdatedDate: dateStr,
              lastUpdatedBy: user,
              remarks: this.formRemarks
            };
          } else {
            const newRecord: LocationMasterRecord = {
              locationId: targetLocId || `LOC-${Date.now()}`,
              locationName: this.formLocationName,
              locationCode: this.formLocationCode || 'HUB',
              state: this.formState || 'Operational Hub',
              zone: 'General Zone',
              baseRequired: Number(this.formBaseRequired),
              bufferPercentage: Number(this.formBufferPercentage),
              bufferHeadcount: bufferCount,
              totalTargetCapacity: target,
              lastUpdatedDate: dateStr,
              lastUpdatedBy: user,
              remarks: this.formRemarks
            };
            this.allMasterRecords.unshift(newRecord);
          }

          this.toastr.success(res.message || `Location manpower updated for ${this.formLocationName} (${this.formLocationCode}). Target: ${target} Heads.`, 'Database Master Saved');
          this.recalculateSummary();
          this.backToList();
        } else {
          this.toastr.error(res?.message || 'Failed to update location manpower in database.', 'Save Failed');
        }
      },
      error: (err) => {
        console.error('Error updating location manpower:', err);
        // Fallback to local state update if offline
        const idx = this.allMasterRecords.findIndex(r => r.locationId === targetLocId);
        if (idx !== -1) {
          this.allMasterRecords[idx] = {
            ...this.allMasterRecords[idx],
            baseRequired: Number(this.formBaseRequired),
            bufferPercentage: Number(this.formBufferPercentage),
            bufferHeadcount: bufferCount,
            totalTargetCapacity: target,
            lastUpdatedDate: dateStr,
            lastUpdatedBy: user,
            remarks: this.formRemarks
          };
        }
        this.toastr.success(`Location manpower updated for ${this.formLocationName} (${this.formLocationCode}). Target: ${target} Heads.`, 'Local Master Saved');
        this.recalculateSummary();
        this.backToList();
      }
    });
  }

  deleteMasterRecord(record: LocationMasterRecord): void {
    if (confirm(`Are you sure you want to delete the manpower master record for ${record.locationName} (${record.locationCode})?`)) {
      this.allMasterRecords = this.allMasterRecords.filter(r => r.locationId !== record.locationId);
      this.recalculateSummary();
      this.toastr.info(`Master record for ${record.locationName} deleted.`, 'Record Deleted');
    }
  }

  // ── 5. EXPORT TO CSV ──────────────────────────────────────────────────────
  exportMasterToCsv(): void {
    if (this.allMasterRecords.length === 0) {
      this.toastr.warning('No records to export.', 'Export');
      return;
    }

    const headers = ['Location ID', 'Location Name', 'Code', 'State', 'Zone', 'Base Sanctioned (Heads)', 'Buffer %', 'Buffer Headcount', 'Target Total Capacity', 'Last Updated Date', 'Last Updated By', 'Remarks'];
    const rows = this.allMasterRecords.map(r => [
      `"${r.locationId}"`,
      `"${r.locationName}"`,
      `"${r.locationCode}"`,
      `"${r.state}"`,
      `"${r.zone}"`,
      r.baseRequired,
      `${r.bufferPercentage}%`,
      r.bufferHeadcount,
      r.totalTargetCapacity,
      `"${r.lastUpdatedDate}"`,
      `"${r.lastUpdatedBy}"`,
      `"${r.remarks || ''}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `REC_Location_Manpower_Master_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    this.toastr.success('Location Manpower Master exported to CSV successfully.', 'Export Complete');
  }
}
